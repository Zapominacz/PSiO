import java.util.Random;


/*
 * Funkcja main weryfikuje poprawność potęgowania,
 * wykonanie poprawnie wszystkich zadań oprócz fooBar 
 * daje 85% wykonania zadań.
 */
public class Lab01 {
	
	
	public static int power(int a, int b) {
		/*
		 * TODO
		 * Napisać funkcję, która wykonuje 
		 * potęgowanie liczby a przez b (a^b)
		 */
		return 0;
	}
	
	
	public static void fooBar() {
		/*
		 * TODO
		 * Napisać funkcję, która za pomocą System.out.println() 
		 * wypisuje na ekran liczby od 1 do 100, przy czym:
		 * - Jeżeli liczba jest podzielna przez 3, to zamiast 
		 * liczby zapisuje "Foo".
		 * - Jeżeli liczba jest podzielna przez 5, to zamiast
		 * liczby zapisuje "Bar".
		 */
	}

	public static void main(String[] args) {
		Random generator = new Random();
		for(int i = 0; i <= 100; i++) {
			int a = generator.nextInt(9) + 1;
			int b = generator.nextInt(8) + 1;
			int result = power(a, b);
			int expected = (int) Math.pow(a, b);
			if(result != expected) {
				throw new RuntimeException("Unexpected result " + a + "^" + b 
						+ ". Was " + result + " expected " + expected);
			}
		}
		System.out.println("Power ok!");
	}

}
